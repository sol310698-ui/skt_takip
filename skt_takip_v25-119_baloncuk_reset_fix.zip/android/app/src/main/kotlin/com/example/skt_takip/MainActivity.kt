package com.example.skt_takip

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Vibrator
import android.os.VibrationEffect
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.View
import java.util.Locale
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

// NOT: FlutterActivity yerine FlutterFragmentActivity kullaniliyor.
// local_auth (parmak izi/yuz tanima) paketinin resmi gereksinimi budur;
// biyometri dialog'u bir Fragment uzerinden gosterilir. Bu degisiklik
// alarm paketinin kilit ekrani davranisini ETKILEMEZ (asagidaki not
// gecerliligini koruyor, sadece temel Activity sinifi degisti).
class MainActivity : FlutterFragmentActivity() {
    private val channel = "skt_takip/fullscreen"

    // FIYAT KONTROL ASISTANI icin ayri kanal. Mevcut "fullscreen" kanaliyla
    // hicbir ilgisi yoktur; bagimsiz calisir.
    private val priceChannel = "skt_takip/price_check"
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // Baloncuktan "hizli QR" istegi geldi mi? Flutter consumeQuickScan ile
    // okur. onCreate/onNewIntent intent extra'sindan set edilir.
    private var pendingQuickScan = false

    // priceChannel referansi — onNewIntent'ten Flutter'a haber gondermek icin.
    private var quickScanChannel: MethodChannel? = null

    // ONEMLI: Activity'ye kilit ekrani bayraklari (setShowWhenLocked /
    // setTurnScreenOn) EKLEMIYORUZ. "alarm" paketi 5.x, alarm calarken kilit
    // ekrani uzerinde gosterimi ve ekrani uyandirmayi KENDI yonetir. Resmi
    // kurulum rehberi de v5'e gecerken bu bayraklarin KALDIRILMASINI soyler.
    // Bunlari MainActivity'de zorlamak, paketin full-screen intent yonetimiyle
    // CAKISARAK alarm ekraninin acilip kapanmasina ve kilit ekraninin one
    // gecip parola istemesine yol aciyordu. Bu yuzden tamamen kaldirildi.

    // EDGE-TO-EDGE (status bar GIZLENMEZ, ICERIK ALTINA UZANIR):
    //  Eski yaklasim status bar'i tamamen gizliyordu (fullscreen +
    //  immersiveSticky). Bu, Xiaomi/MIUI cihazlarda status bar bolgesinde
    //  SIYAH SERIT birakiyordu. Yeni yaklasim status bar'i GIZLEMEZ;
    //  onun yerine SEFFAF yapar ve uygulama icerigini (banner gradient /
    //  AppBar) status bar'in ARKASINA uzatir. Boylece status bar her zaman
    //  ust bardaki renkle ayni gorunur; siyah serit OLUSMAZ.
    //
    //  setDecorFitsSystemWindows(false): icerigi sistem cubuklari arkasina
    //  uzat. Cubuk renkleri styles.xml'de transparent. Flutter tarafinda
    //  MediaQuery.padding.top zaten dogru insets'i verir, banner bu kadar
    //  yukari uzanir.
    private fun applyEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyEdgeToEdge()
        if (intent?.getBooleanExtra("openQuickScan", false) == true) {
            pendingQuickScan = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("openQuickScan", false)) {
            pendingQuickScan = true
            // Flutter tarafina haber ver (resume'da consumeQuickScan sorar,
            // ama uygulama zaten acikken aninda tetiklemek icin de gonderir).
            quickScanChannel?.invokeMethod("openQuickScan", null)
        }
    }

    override fun onResume() {
        super.onResume()
        applyEdgeToEdge()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyEdgeToEdge()
        }
    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "canUseFullScreenIntent" -> result.success(canUseFullScreenIntent())
                    "openFullScreenIntentSettings" -> {
                        openFullScreenIntentSettings()
                        result.success(true)
                    }
                    "startKeepAlive" -> {
                        setKeepAliveFlag(true)
                        val svc = Intent(this, KeepAliveService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(svc)
                        } else {
                            startService(svc)
                        }
                        result.success(true)
                    }
                    "stopKeepAlive" -> {
                        setKeepAliveFlag(false)
                        stopService(Intent(this, KeepAliveService::class.java))
                        result.success(true)
                    }
                    "raiseAlarmVolume" -> {
                        raiseAlarmVolume()
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }

        // ── FIYAT KONTROL ASISTANI KANALI ───────────────────────────────
        // Mevcut "fullscreen" kanalindan tamamen bagimsiz. Flutter tarafi
        // bu kanal uzerinden: erisilebilirlik servisinin durumunu sorar,
        // son okunan sistem fiyatini ceker, ayar sayfasini acar, sesli
        // okuma (TTS) ve titresim tetikler.
        val priceCh = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, priceChannel)
        quickScanChannel = priceCh
        priceCh
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isAccessibilityServiceRunning" ->
                        result.success(PriceAccessibilityService.serviceRunning)
                    "openAccessibilitySettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    "getLastSystemPrice" -> {
                        val map = HashMap<String, Any?>()
                        map["price"] = PriceAccessibilityService.lastSystemPrice
                        map["raw"] = PriceAccessibilityService.lastSystemPriceRaw
                        map["barcode"] = PriceAccessibilityService.lastBarcode
                        map["stockCode"] = PriceAccessibilityService.lastStockCode
                        map["productName"] = PriceAccessibilityService.lastProductName
                        result.success(map)
                    }
                    "getDebugInfo" -> {
                        val map = HashMap<String, Any?>()
                        map["running"] = PriceAccessibilityService.serviceRunning
                        map["price"] = PriceAccessibilityService.lastSystemPrice
                        map["raw"] = PriceAccessibilityService.lastSystemPriceRaw
                        map["barcode"] = PriceAccessibilityService.lastBarcode
                        map["stockCode"] = PriceAccessibilityService.lastStockCode
                        map["productName"] = PriceAccessibilityService.lastProductName
                        map["lastEventTime"] = PriceAccessibilityService.lastEventTime
                        map["lastPackage"] = PriceAccessibilityService.lastPackage
                        map["labelFound"] = PriceAccessibilityService.lastLabelFound
                        map["screenSample"] = PriceAccessibilityService.lastScreenSample
                        result.success(map)
                    }
                    "clearLastSystemPrice" -> {
                        PriceAccessibilityService.clearLastPrice()
                        result.success(true)
                    }
                    "speak" -> {
                        val text = call.argument<String>("text") ?: ""
                        speak(text)
                        result.success(true)
                    }
                    "vibrate" -> {
                        val mismatch = call.argument<Boolean>("mismatch") ?: false
                        vibrate(mismatch)
                        result.success(true)
                    }
                    "canDrawOverlays" -> {
                        val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            Settings.canDrawOverlays(this) else true
                        result.success(ok)
                    }
                    "requestOverlayPermission" -> {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                                !Settings.canDrawOverlays(this)
                            ) {
                                val i = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    android.net.Uri.parse("package:$packageName")
                                )
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(i)
                            }
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    "startOverlay" -> {
                        try {
                            val i = Intent(this, PriceOverlayService::class.java)
                            i.action = PriceOverlayService.ACTION_START
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(i)
                            } else {
                                startService(i)
                            }
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    "stopOverlay" -> {
                        val i = Intent(this, PriceOverlayService::class.java)
                        i.action = PriceOverlayService.ACTION_STOP
                        stopService(i)
                        result.success(true)
                    }
                    "isOverlayRunning" -> {
                        result.success(PriceOverlayService.isRunning)
                    }
                    "updateOverlayState" -> {
                        val state = call.argument<String>("state") ?: "neutral"
                        PriceOverlayService.pendingState = state
                        if (PriceOverlayService.isRunning) {
                            val i = Intent(this, PriceOverlayService::class.java)
                            i.action = PriceOverlayService.ACTION_UPDATE
                            i.putExtra(PriceOverlayService.EXTRA_STATE, state)
                            startService(i)
                        }
                        result.success(true)
                    }
                    "consumeQuickScan" -> {
                        // Flutter acilista/resume'da sorar: baloncuktan QR
                        // modu istegi var mi? Varsa true doner ve bayragi siler.
                        val want = pendingQuickScan
                        pendingQuickScan = false
                        result.success(want)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ── TTS (sesli okuma) ───────────────────────────────────────────────
    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                try {
                    tts?.language = Locale("tr", "TR")
                    // Daha hizli okuma (varsayilan 1.0 -> 1.5).
                    tts?.setSpeechRate(1.5f)
                } catch (_: Exception) {
                }
                ttsReady = true
            }
        }
    }

    private fun speak(text: String) {
        ensureTts()
        try {
            if (ttsReady) {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "price_check")
            } else {
                // TTS hazir degilse kisa bir gecikmeyle tekrar dene.
                tts?.setOnUtteranceProgressListener(null)
            }
        } catch (_: Exception) {
        }
    }

    // ── Titresim ────────────────────────────────────────────────────────
    private fun vibrate(mismatch: Boolean) {
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            // Uyusmazlik: guclu, tekrarli desen. Uyumlu: tek kisa titresim.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (mismatch) {
                    val pattern = longArrayOf(0, 400, 150, 400, 150, 400)
                    vib.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    vib.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            } else {
                @Suppress("DEPRECATION")
                if (mismatch) {
                    vib.vibrate(longArrayOf(0, 400, 150, 400, 150, 400), -1)
                } else {
                    vib.vibrate(120)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        super.onDestroy()
    }

    // Android 14+ (API 34): tam ekran intent izni var mi?
    private fun canUseFullScreenIntent(): Boolean {
        if (Build.VERSION.SDK_INT >= 34) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return nm.canUseFullScreenIntent()
        }
        return true // API 33 ve altinda otomatik var
    }

    // Tam ekran intent izni ayar sayfasini ac (Android 14+).
    private fun openFullScreenIntentSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:$packageName")
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                // Yedek: uygulama detay ayarlari
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        }
    }

    // Boot sonrasi BootReceiver'in okuyabilmesi icin kalici servis tercihini
    // DUZ (sifresiz) SharedPreferences'a yaz. flutter_secure_storage native
    // taraftan kolay okunamadigi icin ayri bir bayrak tutuyoruz.
    private fun setKeepAliveFlag(on: Boolean) {
        try {
            val sp = getSharedPreferences("skt_native_prefs", Context.MODE_PRIVATE)
            sp.edit().putBoolean("keep_alive_on", on).apply()
        } catch (_: Exception) {
        }
    }

    // STREAM_ALARM ses seviyesini maksimuma cikar (alarm 1 dk kapatilmadiysa).
    private fun raiseAlarmVolume() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
        } catch (e: Exception) {
            // sessizce gec
        }
    }
}
